import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent {
  @Input() msg = '';
  @Output() myEvent = new EventEmitter();

  public SendMsg(){
    this.myEvent.emit("Msg from Child to Parent");
  }
}
